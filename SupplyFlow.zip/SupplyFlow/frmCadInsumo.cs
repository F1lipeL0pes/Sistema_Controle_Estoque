﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupplyFlow
{
    public partial class frmCadInsumo : Form
    {
        public frmCadInsumo()
        {
            InitializeComponent();
        }


        private void lblTela_Click(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {

        }

        private void lboCardapio_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lboProduto_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblCardapio_Click(object sender, EventArgs e)
        {

        }

        private void lblProduto_Click(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblQuantidade_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
