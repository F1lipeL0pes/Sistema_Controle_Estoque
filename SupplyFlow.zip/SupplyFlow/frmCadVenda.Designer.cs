﻿namespace SupplyFlow
{
    partial class frmCadVenda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnConfirmar = new System.Windows.Forms.Button();
            this.btnVoltar = new System.Windows.Forms.Button();
            this.lblTela = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.lboPrato = new System.Windows.Forms.ListBox();
            this.lblPrato = new System.Windows.Forms.Label();
            this.lblBebida = new System.Windows.Forms.Label();
            this.lboBebida = new System.Windows.Forms.ListBox();
            this.lblSobremesa = new System.Windows.Forms.Label();
            this.lboSobremesa = new System.Windows.Forms.ListBox();
            this.lblMesa = new System.Windows.Forms.Label();
            this.lboMesa = new System.Windows.Forms.ListBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnConfirmar
            // 
            this.btnConfirmar.BackColor = System.Drawing.Color.MediumTurquoise;
            this.btnConfirmar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirmar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnConfirmar.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirmar.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnConfirmar.Location = new System.Drawing.Point(342, 353);
            this.btnConfirmar.Name = "btnConfirmar";
            this.btnConfirmar.Size = new System.Drawing.Size(157, 46);
            this.btnConfirmar.TabIndex = 7;
            this.btnConfirmar.Text = "Confirmar";
            this.btnConfirmar.UseVisualStyleBackColor = false;
            // 
            // btnVoltar
            // 
            this.btnVoltar.BackColor = System.Drawing.Color.Teal;
            this.btnVoltar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVoltar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVoltar.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVoltar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnVoltar.Location = new System.Drawing.Point(537, 0);
            this.btnVoltar.Name = "btnVoltar";
            this.btnVoltar.Size = new System.Drawing.Size(148, 54);
            this.btnVoltar.TabIndex = 12;
            this.btnVoltar.Text = "Voltar";
            this.btnVoltar.UseVisualStyleBackColor = false;
            this.btnVoltar.Click += new System.EventHandler(this.btnVoltar_Click);
            // 
            // lblTela
            // 
            this.lblTela.AutoSize = true;
            this.lblTela.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTela.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTela.Location = new System.Drawing.Point(3, 15);
            this.lblTela.Name = "lblTela";
            this.lblTela.Size = new System.Drawing.Size(201, 24);
            this.lblTela.TabIndex = 2;
            this.lblTela.Text = "Cadastro de Venda";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.btnVoltar);
            this.panel1.Controls.Add(this.lblTela);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(685, 54);
            this.panel1.TabIndex = 12;
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnCancelar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelar.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCancelar.Location = new System.Drawing.Point(515, 353);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(157, 46);
            this.btnCancelar.TabIndex = 13;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            // 
            // lboPrato
            // 
            this.lboPrato.BackColor = System.Drawing.Color.Azure;
            this.lboPrato.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lboPrato.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lboPrato.FormattingEnabled = true;
            this.lboPrato.ItemHeight = 18;
            this.lboPrato.Location = new System.Drawing.Point(153, 103);
            this.lboPrato.Name = "lboPrato";
            this.lboPrato.Size = new System.Drawing.Size(325, 20);
            this.lboPrato.TabIndex = 14;
            // 
            // lblPrato
            // 
            this.lblPrato.AutoSize = true;
            this.lblPrato.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrato.ForeColor = System.Drawing.Color.Black;
            this.lblPrato.Location = new System.Drawing.Point(70, 101);
            this.lblPrato.Name = "lblPrato";
            this.lblPrato.Size = new System.Drawing.Size(71, 24);
            this.lblPrato.TabIndex = 13;
            this.lblPrato.Text = "Prato:";
            // 
            // lblBebida
            // 
            this.lblBebida.AutoSize = true;
            this.lblBebida.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBebida.ForeColor = System.Drawing.Color.Black;
            this.lblBebida.Location = new System.Drawing.Point(54, 162);
            this.lblBebida.Name = "lblBebida";
            this.lblBebida.Size = new System.Drawing.Size(87, 24);
            this.lblBebida.TabIndex = 15;
            this.lblBebida.Text = "Bebida:";
            // 
            // lboBebida
            // 
            this.lboBebida.BackColor = System.Drawing.Color.Azure;
            this.lboBebida.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lboBebida.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lboBebida.FormattingEnabled = true;
            this.lboBebida.ItemHeight = 18;
            this.lboBebida.Location = new System.Drawing.Point(153, 164);
            this.lboBebida.Name = "lboBebida";
            this.lboBebida.Size = new System.Drawing.Size(325, 20);
            this.lboBebida.TabIndex = 16;
            // 
            // lblSobremesa
            // 
            this.lblSobremesa.AutoSize = true;
            this.lblSobremesa.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSobremesa.ForeColor = System.Drawing.Color.Black;
            this.lblSobremesa.Location = new System.Drawing.Point(9, 220);
            this.lblSobremesa.Name = "lblSobremesa";
            this.lblSobremesa.Size = new System.Drawing.Size(132, 24);
            this.lblSobremesa.TabIndex = 17;
            this.lblSobremesa.Text = "Sobremesa:";
            // 
            // lboSobremesa
            // 
            this.lboSobremesa.BackColor = System.Drawing.Color.Azure;
            this.lboSobremesa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lboSobremesa.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lboSobremesa.FormattingEnabled = true;
            this.lboSobremesa.ItemHeight = 18;
            this.lboSobremesa.Location = new System.Drawing.Point(153, 222);
            this.lboSobremesa.Name = "lboSobremesa";
            this.lboSobremesa.Size = new System.Drawing.Size(325, 20);
            this.lboSobremesa.TabIndex = 18;
            // 
            // lblMesa
            // 
            this.lblMesa.AutoSize = true;
            this.lblMesa.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMesa.ForeColor = System.Drawing.Color.Black;
            this.lblMesa.Location = new System.Drawing.Point(71, 277);
            this.lblMesa.Name = "lblMesa";
            this.lblMesa.Size = new System.Drawing.Size(70, 24);
            this.lblMesa.TabIndex = 19;
            this.lblMesa.Text = "Mesa:";
            // 
            // lboMesa
            // 
            this.lboMesa.BackColor = System.Drawing.Color.Azure;
            this.lboMesa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lboMesa.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lboMesa.FormattingEnabled = true;
            this.lboMesa.ItemHeight = 18;
            this.lboMesa.Location = new System.Drawing.Point(153, 279);
            this.lboMesa.Name = "lboMesa";
            this.lboMesa.Size = new System.Drawing.Size(111, 20);
            this.lboMesa.TabIndex = 20;
            // 
            // frmCadVenda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(684, 411);
            this.Controls.Add(this.lboMesa);
            this.Controls.Add(this.lblMesa);
            this.Controls.Add(this.lblSobremesa);
            this.Controls.Add(this.lboSobremesa);
            this.Controls.Add(this.lblBebida);
            this.Controls.Add(this.lboBebida);
            this.Controls.Add(this.lblPrato);
            this.Controls.Add(this.lboPrato);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnConfirmar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmCadVenda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastrar Venda";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnConfirmar;
        private System.Windows.Forms.Button btnVoltar;
        private System.Windows.Forms.Label lblTela;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.ListBox lboPrato;
        private System.Windows.Forms.Label lblPrato;
        private System.Windows.Forms.Label lblBebida;
        private System.Windows.Forms.ListBox lboBebida;
        private System.Windows.Forms.Label lblSobremesa;
        private System.Windows.Forms.ListBox lboSobremesa;
        private System.Windows.Forms.Label lblMesa;
        private System.Windows.Forms.ListBox lboMesa;
    }
}