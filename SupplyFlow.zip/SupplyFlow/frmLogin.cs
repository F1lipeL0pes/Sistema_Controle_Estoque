﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupplyFlow
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            /*
            frmGarcom Garcom = new frmGarcom();
            Garcom.Show();
            this.Hide();
            */
            frmEstoque estoque = new frmEstoque();
            estoque.Show();
            this.Hide();
        }
    }
}
