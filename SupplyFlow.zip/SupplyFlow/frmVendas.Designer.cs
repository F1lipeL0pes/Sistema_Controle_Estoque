﻿namespace SupplyFlow
{
    partial class frmVendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRealizarVenda = new System.Windows.Forms.Button();
            this.btnEditarVenda = new System.Windows.Forms.Button();
            this.btnVisualizarVenda = new System.Windows.Forms.Button();
            this.btnCardapio = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSair = new System.Windows.Forms.Button();
            this.lblTela = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnRealizarVenda
            // 
            this.btnRealizarVenda.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnRealizarVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRealizarVenda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRealizarVenda.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRealizarVenda.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnRealizarVenda.Location = new System.Drawing.Point(22, 99);
            this.btnRealizarVenda.Name = "btnRealizarVenda";
            this.btnRealizarVenda.Size = new System.Drawing.Size(256, 46);
            this.btnRealizarVenda.TabIndex = 6;
            this.btnRealizarVenda.Text = "Realizar Venda";
            this.btnRealizarVenda.UseVisualStyleBackColor = false;
            this.btnRealizarVenda.Click += new System.EventHandler(this.btnRealizarVenda_Click);
            // 
            // btnEditarVenda
            // 
            this.btnEditarVenda.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnEditarVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEditarVenda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEditarVenda.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditarVenda.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnEditarVenda.Location = new System.Drawing.Point(22, 224);
            this.btnEditarVenda.Name = "btnEditarVenda";
            this.btnEditarVenda.Size = new System.Drawing.Size(256, 46);
            this.btnEditarVenda.TabIndex = 7;
            this.btnEditarVenda.Text = "Editar/Cancelar Venda";
            this.btnEditarVenda.UseVisualStyleBackColor = false;
            this.btnEditarVenda.Click += new System.EventHandler(this.btnEditarVenda_Click);
            // 
            // btnVisualizarVenda
            // 
            this.btnVisualizarVenda.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnVisualizarVenda.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVisualizarVenda.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVisualizarVenda.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVisualizarVenda.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnVisualizarVenda.Location = new System.Drawing.Point(403, 99);
            this.btnVisualizarVenda.Name = "btnVisualizarVenda";
            this.btnVisualizarVenda.Size = new System.Drawing.Size(256, 46);
            this.btnVisualizarVenda.TabIndex = 8;
            this.btnVisualizarVenda.Text = "Visualizar Vendas";
            this.btnVisualizarVenda.UseVisualStyleBackColor = false;
            this.btnVisualizarVenda.Click += new System.EventHandler(this.btnVisualizarVenda_Click);
            // 
            // btnCardapio
            // 
            this.btnCardapio.BackColor = System.Drawing.Color.DarkSlateGray;
            this.btnCardapio.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCardapio.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCardapio.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCardapio.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnCardapio.Location = new System.Drawing.Point(403, 224);
            this.btnCardapio.Name = "btnCardapio";
            this.btnCardapio.Size = new System.Drawing.Size(256, 46);
            this.btnCardapio.TabIndex = 10;
            this.btnCardapio.Text = "Acessar Cardápio";
            this.btnCardapio.UseVisualStyleBackColor = false;
            this.btnCardapio.Click += new System.EventHandler(this.btnCardapio_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkSlateGray;
            this.panel1.Controls.Add(this.btnSair);
            this.panel1.Controls.Add(this.lblTela);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(685, 54);
            this.panel1.TabIndex = 11;
            // 
            // btnSair
            // 
            this.btnSair.BackColor = System.Drawing.Color.Teal;
            this.btnSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSair.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btnSair.Location = new System.Drawing.Point(537, 0);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(148, 54);
            this.btnSair.TabIndex = 12;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = false;
            this.btnSair.Click += new System.EventHandler(this.btnVoltar_Click);
            // 
            // lblTela
            // 
            this.lblTela.AutoSize = true;
            this.lblTela.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTela.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTela.Location = new System.Drawing.Point(3, 15);
            this.lblTela.Name = "lblTela";
            this.lblTela.Size = new System.Drawing.Size(84, 24);
            this.lblTela.TabIndex = 2;
            this.lblTela.Text = "Vendas";
            // 
            // frmVendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(684, 411);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnCardapio);
            this.Controls.Add(this.btnVisualizarVenda);
            this.Controls.Add(this.btnEditarVenda);
            this.Controls.Add(this.btnRealizarVenda);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "frmVendas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Garçom";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnRealizarVenda;
        private System.Windows.Forms.Button btnEditarVenda;
        private System.Windows.Forms.Button btnVisualizarVenda;
        private System.Windows.Forms.Button btnCardapio;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Label lblTela;
    }
}