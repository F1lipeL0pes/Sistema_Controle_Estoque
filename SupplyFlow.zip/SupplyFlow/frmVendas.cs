﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SupplyFlow
{
    public partial class frmVendas : Form
    {
        public frmVendas()
        {
            InitializeComponent();
        }

        private void btnRealizarVenda_Click(object sender, EventArgs e)
        {
            frmCadVenda RealizarVenda = new frmCadVenda();
            RealizarVenda.Show();
            this.Hide();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnVisualizarVenda_Click(object sender, EventArgs e)
        {
            frmVendasGarcom vendasGarcom = new frmVendasGarcom();
            vendasGarcom.Show();
            this.Hide();
        }

        private void btnCardapio_Click(object sender, EventArgs e)
        {

        }

        private void btnEditarVenda_Click(object sender, EventArgs e)
        {
            frmEditarVenda editarVenda = new frmEditarVenda();
            editarVenda.Show();
            this.Hide();
        }
    }
}
